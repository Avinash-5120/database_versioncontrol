#include<stdio.h>
#include<stdlib.h>
#include"str2.h"
int main()
{
	FILE *fp = fopen("sample.bin", "wb");
	FILE *rd = fopen("sample2.csv", "rt");
	char **strings,buf[50];
	
	int i = 0;
	struct ch
	{
		//short b;
		int a;
		char na[32];
		char diatrict[20];
	};
	ch b[6];
	while ((fgets(buf, 49, rd) != NULL)&&i!=6)
	{
		int num=0;
		strings = splitStr(buf, ',', &num);
		b[i].a = str_to_num(strings[0]);
		str_cpy(strings[1], b[i].na);
		str_cpy(strings[2], b[i].diatrict);
		i++;
	}
	fwrite(b,sizeof(struct ch),6, fp);
	fclose(fp);
	//fp=fopen("sample2.bin", "w");
	//fwrite(&b, sizeof(v), 1, fp);
	system("pause");
}